from get_a_poem import main

main()